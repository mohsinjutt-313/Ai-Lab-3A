import os
import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Crop Yield Predictor", layout="wide")
st.title("🌾 Crop Yield Prediction")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, "crop_yield.csv")

if not os.path.exists(CSV_PATH):
    st.error(f"CSV nahi mila: {CSV_PATH}")
    st.stop()

# Data load karo
df = pd.read_csv(CSV_PATH)
df.columns = [c.strip() for c in df.columns]

if "Season" in df.columns:
    df["Season"] = df["Season"].astype(str).str.strip()

st.sidebar.header("Settings")
crop_list = sorted(df["Crop"].unique().tolist())
selected_crop = st.sidebar.selectbox("Crop select karo", options=["Sab"] + crop_list, index=0)

# Filter data
if selected_crop != "Sab":
    df_model = df[df["Crop"] == selected_crop].copy()
else:
    df_model = df.copy()

# Numeric aur categorical columns
numeric_cols = ["Area", "Annual_Rainfall", "Fertilizer", "Pesticide"]
numeric_cols = [c for c in numeric_cols if c in df.columns]
categorical_cols = ["Season", "State"]
categorical_cols = [c for c in categorical_cols if c in df.columns]

# Design matrix banana (simple)
X_list = []
for idx, row in df_model.iterrows():
    x_row = [1.0]  # intercept
    for col in numeric_cols:
        x_row.append(float(row[col]))
    for col in categorical_cols:
        val = str(row[col]).strip()
        unique_vals = sorted(df_model[col].unique().tolist())
        for uval in unique_vals:
            x_row.append(1.0 if val == str(uval).strip() else 0.0)
    X_list.append(x_row)

X = np.array(X_list)
y = df_model["Yield"].values

# Train model (numpy)
coef, *_ = np.linalg.lstsq(X, y, rcond=None)

# Test accuracy
y_pred = X.dot(coef)
rmse = float(np.sqrt(np.mean((y - y_pred) ** 2)))
r2 = float(1 - np.sum((y - y_pred)**2) / np.sum((y - np.mean(y))**2))

# UI - Left aur Right
left_col, right_col = st.columns([1, 1])

with left_col:
    st.markdown("### 📝 Input Karo")
    
    input_vals = {}
    
    # Numeric inputs
    for col in numeric_cols:
        default_val = float(df_model[col].median())
        input_vals[col] = st.number_input(col, value=default_val, format="%.2f")
    
    # Categorical inputs - directly from CSV data
    for col in categorical_cols:
        options = sorted(df[col].unique().tolist())
        options = [str(o).strip() for o in options]
        input_vals[col] = st.selectbox(col, options)
    
    predict_btn = st.button("🌾 Predict", use_container_width=True)

with right_col:
    st.markdown("### 📊 Result")
    
    if predict_btn:
        # Input ko vector mein convert karo
        x_input = [1.0]
        for col in numeric_cols:
            x_input.append(float(input_vals[col]))
        for col in categorical_cols:
            val = str(input_vals[col]).strip()
            unique_vals = sorted(df_model[col].unique().tolist())
            for uval in unique_vals:
                x_input.append(1.0 if val == str(uval).strip() else 0.0)
        
        x_input = np.array(x_input)
        prediction = float(x_input.dot(coef))
        
        # Display results as card/boxes (na ke table)
        st.markdown("---")
        
        # Crop info
        st.markdown(f"**🌾 Crop:** {selected_crop if selected_crop != 'Sab' else 'All Crops'}")
        
        # Input values display
        st.markdown("**📋 Input Values:**")
        input_col1, input_col2 = st.columns(2)
        
        with input_col1:
            st.write(f"• **Area:** {input_vals.get('Area', 0):.2f}")
            st.write(f"• **Fertilizer:** {input_vals.get('Fertilizer', 0):.2f}")
        
        with input_col2:
            st.write(f"• **Rainfall:** {input_vals.get('Annual_Rainfall', 0):.2f}")
            st.write(f"• **Pesticide:** {input_vals.get('Pesticide', 0):.2f}")
        
        st.markdown("---")
        
        # Season aur State display
        st.markdown("**🌍 Location & Season:**")
        location_col1, location_col2 = st.columns(2)
        
        with location_col1:
            st.write(f"• **Season:** {input_vals.get('Season', 'N/A')}")
        
        with location_col2:
            st.write(f"• **State:** {input_vals.get('State', 'N/A')}")
        
        st.markdown("---")
        
        # Main prediction
        st.markdown("### 🎯 Predicted Yield")
        st.markdown(f"<h1 style='color: green; text-align: center;'>{prediction:.2f}</h1>", unsafe_allow_html=True)
        
        st.markdown("---")
        
        # Metrics
        metric_col1, metric_col2, metric_col3 = st.columns(3)
        
        with metric_col1:
            st.metric("Yield Value", f"{prediction:.4f}")
        
        with metric_col2:
            st.metric("Model R² Score", f"{r2:.3f}")
        
        with metric_col3:
            st.metric("Model RMSE", f"{rmse:.2f}")
    
    else:
        st.info("👈 Left side fill karo aur Predict button dabao")